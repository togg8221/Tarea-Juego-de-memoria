//: Tarea: Juego de memoria

import UIKit

var números = 0...100

for n in números{
    
    switch n {
    case 30...40:
        print("#\(n) Viva Swift!!!")
    default:
        if(n % 5 == 0){
        print("#\(n) Bingo!!!")
        }else if(n % 2 == 0){
        print("#\(n) par!!!")
        }else{
        print("#\(n) impar!!!")
        }
    }

}

